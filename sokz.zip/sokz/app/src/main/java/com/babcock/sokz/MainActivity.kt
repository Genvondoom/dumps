package com.babcock.sokz

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

import java.io.OutputStream
import java.net.Socket
import java.util.*
import kotlin.concurrent.thread
import android.os.StrictMode
import android.os.StrictMode.ThreadPolicy
import android.widget.EditText
import java.io.InputStream
import java.lang.Exception


class MainActivity : AppCompatActivity() {
    private var active: Boolean = false

    lateinit var matricNo: EditText
    lateinit var password: EditText
    lateinit var button: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val policy = ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        val clientz = Socket("192.168.43.63", 3309)
        val clientOutput = clientz.getOutputStream()
        val clientInput = clientz.getInputStream()


        matricNo = findViewById(R.id.matric)
        password = findViewById(R.id.password)
        button = findViewById(R.id.btn1)
        button.setOnClickListener {


            clientOutput.write("login,${matricNo.text},${password.text}".toByteArray())
            if (recvMesage(clientInput) == "success") {
                val intent = Intent(this, HomePage::class.java)
                startActivity(intent)
            }


        }
    }

    fun recvMesage(clientzInput: InputStream): String {
        val recvMsglist = mutableListOf<Char>()
        while (true) {

            var nextByte = clientzInput.read()
            if (nextByte.toChar() != '.') {
                recvMsglist.add(nextByte.toChar())

            } else {

                val msg = recvMsglist.joinToString("")
                recvMsglist.clear()
                return msg


            }

        }

    }
}


